"""
calibrate_l1_triage.py
=======================
Re-derives ESCALATION_THRESHOLD (used by gen_ai_l1_decision() in
generate_investigation_data.py) against ANY investigation_data.json,
including a future, larger, real production dataset. This is the "pattern
training" step for the SARA.ai L1 auto-triage model -- run this whenever a
new dataset is loaded, rather than hand-picking a new threshold.

WHY A PERCENTILE CUT, NOT A FIXED SCORE:
A fixed evidence-score cutoff (e.g. "escalate anything over 65") only
behaves consistently if every new dataset's score distribution looks like
this one's. It won't. A percentile cut instead asks a population-relative
question -- "escalate only the alerts whose combined evidence clearly
separates them from the rest of THIS population" -- which is what actually
generalises: at small/curated demo scale the cut naturally lands wherever
this dataset's genuine standout cases are; at real production scale, where
the vast majority of alerts cluster at low evidence (consistent with
published ~90-98% false-positive rates), the same method naturally pushes
the effective escalation rate down toward that same industry-typical
operating point without anyone re-tuning a magic number by hand.

USAGE:
    python3 scripts/calibrate_l1_triage.py [path/to/investigation_data.json] [--target-rate 0.10]

    --target-rate sets what fraction of alerts should clear the bar
    (default 0.10, i.e. escalate roughly the strongest-evidence decile).
    For a large, realistic alert population aiming at the ~2% escalation /
    98% auto-close industry benchmark, run with --target-rate 0.02.

OUTPUT: prints the recommended ESCALATION_THRESHOLD to set in
generate_investigation_data.py, plus the resulting close/escalate split, so
a reviewer can sanity-check the cut before adopting it.
"""

import argparse
import json
import sys
from pathlib import Path

# escalation_evidence_score() is duplicated here (not imported) on purpose:
# this script is meant to be runnable standalone against a data export, even
# from a downstream analytics environment that doesn't have the generator
# module available. Keep this in sync with generate_investigation_data.py if
# the weighting ever changes.
def escalation_evidence_score(max_ai_score, red_flag_weight_total, corroboration_count):
    weight_component = min(red_flag_weight_total, 100)
    corrob_component = (corroboration_count / 3) * 100
    return round(0.55 * max_ai_score + 0.30 * weight_component + 0.15 * corrob_component, 1)


def load_scores(investigation_data_path):
    with open(investigation_data_path) as f:
        inv = json.load(f)

    rows = []
    for cust_id, rec in inv.items():
        d = rec.get("ai_l1_decision", {})
        if d.get("final_action") == "escalate_to_l2" and d.get("escalation_evidence_score") is None:
            # mandatory sanctions escalation -- not part of the scored population,
            # it never goes through the threshold at all.
            continue
        pep = rec.get("pep_screening", {}).get("pep_flag") == "Y"
        osint = rec.get("osint", {}).get("negative_news") == "Y"
        aml = rec.get("aml_history", {}).get("history_available") == "Y"
        corrob = sum([pep, osint, aml])
        score = d.get("max_ai_confidence_score", 0)
        rfw = d.get("red_flag_weight_total", 0)
        evidence = escalation_evidence_score(score, rfw, corrob)
        rows.append((evidence, cust_id))
    rows.sort(reverse=True)
    return rows


def recommend_threshold(rows, target_rate):
    if not rows:
        return None, 0
    n = len(rows)
    cut_index = max(0, round(n * target_rate) - 1)
    cut_index = min(cut_index, n - 1)
    threshold = rows[cut_index][0]
    n_escalate = sum(1 for evidence, _ in rows if evidence >= threshold)
    return threshold, n_escalate


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("data_path", nargs="?", default="output/investigation_data.json")
    ap.add_argument("--target-rate", type=float, default=0.10,
                     help="Target fraction of (non-sanctions) alerts to escalate. "
                          "Default 0.10. Use 0.02 to aim at the ~98%% auto-close industry benchmark "
                          "on a large, realistic dataset.")
    args = ap.parse_args()

    path = Path(args.data_path)
    if not path.exists():
        print(f"ERROR: {path} not found.", file=sys.stderr)
        sys.exit(1)

    rows = load_scores(path)
    n_total = len(rows)
    threshold, n_escalate = recommend_threshold(rows, args.target_rate)
    n_close = n_total - n_escalate

    print(f"Scored {n_total} alerts (excludes mandatory sanctions escalations) from {path}")
    print(f"Target escalation rate: {args.target_rate:.1%}")
    print()
    print(f"RECOMMENDED ESCALATION_THRESHOLD = {threshold}")
    print(f"  -> would escalate {n_escalate}/{n_total} ({n_escalate/n_total:.1%})")
    print(f"  -> would auto-close {n_close}/{n_total} ({n_close/n_total:.1%}) as false positives")
    print()
    print("Top 10 alerts by evidence score (sanity-check these are genuinely the strongest cases):")
    for evidence, cust_id in rows[:10]:
        marker = " <= escalates" if evidence >= threshold else ""
        print(f"  {evidence:>6}  {cust_id}{marker}")
    print()
    print("If this looks right, set ESCALATION_THRESHOLD to the recommended value in")
    print("generate_investigation_data.py and re-run the data-generation pipeline.")


if __name__ == "__main__":
    main()
