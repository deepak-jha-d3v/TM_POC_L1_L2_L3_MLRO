"""
test_triage_engine.py
======================
Unit / boundary / negative / randomized / stress tests for triage_engine.py.
Stdlib-only (unittest) so it runs anywhere with no extra dependencies.

Run:
    python3 -m unittest test_triage_engine.py -v
"""

import random
import time
import unittest

from triage_engine import (
    CalibrationResult,
    Disposition,
    EvidenceInput,
    TriageError,
    calibrate_threshold,
    decide_l1_triage,
    escalation_evidence_score,
)


# ============================================================================
# UNIT TESTS -- escalation_evidence_score correctness
# ============================================================================
class TestEscalationEvidenceScoreUnit(unittest.TestCase):
    def test_known_value_no_corroboration(self):
        # 0.55*100 + 0.30*95 + 0.15*0 = 55 + 28.5 + 0 = 83.5
        self.assertEqual(escalation_evidence_score(100, 95, 0), 83.5)

    def test_known_value_full_corroboration(self):
        # 0.55*75 + 0.30*60 + 0.15*100 = 41.25 + 18 + 15 = 74.25 -> rounds to 74.2 (banker's/half-even at .25? verify)
        result = escalation_evidence_score(75, 60, 3)
        self.assertAlmostEqual(result, 74.2, places=1)

    def test_zero_everything(self):
        self.assertEqual(escalation_evidence_score(0, 0, 0), 0.0)

    def test_max_everything(self):
        self.assertEqual(escalation_evidence_score(100, 100, 3), 100.0)

    def test_red_flag_weight_above_cap_is_clamped(self):
        # 220 (max theoretical red-flag weight total) should score identically to 100
        self.assertEqual(
            escalation_evidence_score(50, 220, 1),
            escalation_evidence_score(50, 100, 1),
        )

    def test_corroboration_scales_linearly(self):
        s0 = escalation_evidence_score(50, 50, 0)
        s1 = escalation_evidence_score(50, 50, 1)
        s2 = escalation_evidence_score(50, 50, 2)
        s3 = escalation_evidence_score(50, 50, 3)
        # each additional corroboration source adds a constant increment
        self.assertAlmostEqual(s1 - s0, s2 - s1, places=6)
        self.assertAlmostEqual(s2 - s1, s3 - s2, places=6)


# ============================================================================
# BOUNDARY TESTS
# ============================================================================
class TestBoundaries(unittest.TestCase):
    def test_score_lower_bound(self):
        self.assertEqual(escalation_evidence_score(0, 0, 0), 0.0)

    def test_score_upper_bound(self):
        self.assertEqual(escalation_evidence_score(100, 100, 3), 100.0)

    def test_score_just_below_lower_bound_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(-0.001, 0, 0)

    def test_score_just_above_upper_bound_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(100.001, 0, 0)

    def test_corroboration_at_min_and_max(self):
        escalation_evidence_score(50, 50, 0)  # should not raise
        escalation_evidence_score(50, 50, 3)  # should not raise

    def test_corroboration_out_of_range(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, 50, -1)
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, 50, 4)

    def test_decision_boundary_exactly_at_threshold_escalates(self):
        # >= threshold must escalate, not just > threshold
        ev = EvidenceInput.create(max_ai_score=100, red_flag_weight_total=0, corroboration_count=0)
        score = escalation_evidence_score(100, 0, 0)  # 55.0
        decision = decide_l1_triage(ev, threshold=score)
        self.assertEqual(decision.disposition, Disposition.ESCALATE)

    def test_decision_just_below_threshold_closes(self):
        ev = EvidenceInput.create(max_ai_score=100, red_flag_weight_total=0, corroboration_count=0)
        score = escalation_evidence_score(100, 0, 0)  # 55.0
        decision = decide_l1_triage(ev, threshold=score + 0.1)
        self.assertEqual(decision.disposition, Disposition.CLOSE_FALSE_POSITIVE)

    def test_calibration_target_rate_zero_escalates_nobody(self):
        result = calibrate_threshold([10, 20, 100, 100, 100], target_rate=0.0)
        self.assertEqual(result.escalate_count, 0)

    def test_calibration_target_rate_one_escalates_everybody(self):
        scores = [10, 20, 30, 100]
        result = calibrate_threshold(scores, target_rate=1.0)
        self.assertEqual(result.escalate_count, len(scores))

    def test_calibration_empty_population(self):
        result = calibrate_threshold([], target_rate=0.1)
        self.assertEqual(result.population_size, 0)
        self.assertEqual(result.escalate_count, 0)
        self.assertEqual(result.escalate_rate, 0.0)

    def test_calibration_single_element_population(self):
        result = calibrate_threshold([42.0], target_rate=0.5)
        self.assertEqual(result.population_size, 1)
        self.assertEqual(result.escalate_count, 1)

    def test_calibration_result_escalate_rate_property(self):
        # direct unit test of the dataclass's own computed property, not just
        # indirect coverage through calibrate_threshold()
        result = CalibrationResult(threshold=70.0, population_size=40, escalate_count=4)
        self.assertEqual(result.escalate_rate, 0.1)
        zero_pop = CalibrationResult(threshold=100.0, population_size=0, escalate_count=0)
        self.assertEqual(zero_pop.escalate_rate, 0.0)  # must not raise ZeroDivisionError


# ============================================================================
# NEGATIVE TESTS -- invalid / hostile input
# ============================================================================
class TestNegativeInputs(unittest.TestCase):
    def test_none_max_ai_score(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(None, 50, 0)

    def test_none_red_flag_weight(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, None, 0)

    def test_none_corroboration(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, 50, None)

    def test_string_input_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score("100", 50, 0)

    def test_bool_rejected_even_though_int_subclass(self):
        # bool is a subclass of int in Python -- must be explicitly rejected
        # or True/False would silently behave like 1/0.
        with self.assertRaises(TriageError):
            escalation_evidence_score(True, 50, 0)
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, 50, True)

    def test_nan_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(float("nan"), 50, 0)

    def test_infinity_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(float("inf"), 50, 0)
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, float("inf"), 0)

    def test_negative_red_flag_weight_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, -1, 0)

    def test_non_integer_corroboration_rejected(self):
        with self.assertRaises(TriageError):
            escalation_evidence_score(50, 50, 1.5)

    def test_evidence_input_create_rejects_bad_sanctions_type(self):
        with self.assertRaises(TriageError):
            EvidenceInput.create(50, 50, 0, sanctions_match="yes")

    def test_decide_rejects_non_evidence_input(self):
        with self.assertRaises(TriageError):
            decide_l1_triage({"max_ai_score": 100})  # plain dict, not EvidenceInput

    def test_decide_rejects_negative_threshold(self):
        ev = EvidenceInput.create(50, 50, 0)
        with self.assertRaises(TriageError):
            decide_l1_triage(ev, threshold=-1)

    def test_decide_rejects_out_of_range_qc_sample_rate(self):
        ev = EvidenceInput.create(50, 50, 0)
        with self.assertRaises(TriageError):
            decide_l1_triage(ev, qc_sample_rate=1.5)
        with self.assertRaises(TriageError):
            decide_l1_triage(ev, qc_sample_rate=-0.1)

    def test_calibrate_rejects_out_of_range_target_rate(self):
        with self.assertRaises(TriageError):
            calibrate_threshold([1, 2, 3], target_rate=1.5)
        with self.assertRaises(TriageError):
            calibrate_threshold([1, 2, 3], target_rate=-0.1)

    def test_calibrate_rejects_invalid_score_in_population(self):
        with self.assertRaises(TriageError):
            calibrate_threshold([50, None, 70], target_rate=0.1)
        with self.assertRaises(TriageError):
            calibrate_threshold([50, 150, 70], target_rate=0.1)  # 150 > MAX_SCORE

    def test_calibrate_accepts_generator_input(self):
        # regression test for the generator-exhaustion bug found in review
        gen = (float(x) for x in [10, 20, 30, 100])
        result = calibrate_threshold(gen, target_rate=0.25)
        self.assertEqual(result.population_size, 4)
        self.assertGreaterEqual(result.escalate_count, 1)


# ============================================================================
# SANCTIONS OVERRIDE TESTS (mandatory escalation path)
# ============================================================================
class TestSanctionsOverride(unittest.TestCase):
    def test_sanctions_match_escalates_even_with_zero_other_evidence(self):
        ev = EvidenceInput.create(0, 0, 0, sanctions_match=True)
        decision = decide_l1_triage(ev, threshold=999)  # threshold set absurdly high on purpose
        self.assertEqual(decision.disposition, Disposition.ESCALATE)
        self.assertIsNone(decision.evidence_score)
        self.assertIsNone(decision.threshold_used)

    def test_sanctions_match_bypasses_scoring_entirely(self):
        ev = EvidenceInput.create(0, 0, 0, sanctions_match=True)
        decision = decide_l1_triage(ev)
        self.assertIn("sanctions", decision.reason.lower())


# ============================================================================
# RANDOMIZED / PROPERTY-BASED TESTS
# ============================================================================
class TestRandomizedProperties(unittest.TestCase):
    def setUp(self):
        self.rng = random.Random(1337)  # fixed seed -> reproducible failures

    def test_score_always_in_valid_range(self):
        for _ in range(5000):
            score = self.rng.uniform(0, 100)
            weight = self.rng.uniform(0, 500)
            corrob = self.rng.randint(0, 3)
            result = escalation_evidence_score(score, weight, corrob)
            self.assertGreaterEqual(result, 0.0)
            self.assertLessEqual(result, 100.0)

    def test_monotonic_in_ai_score(self):
        # increasing max_ai_score, holding everything else fixed, must never
        # decrease the composite score
        for _ in range(500):
            weight = self.rng.uniform(0, 200)
            corrob = self.rng.randint(0, 3)
            a, b = sorted([self.rng.uniform(0, 100), self.rng.uniform(0, 100)])
            self.assertLessEqual(
                escalation_evidence_score(a, weight, corrob),
                escalation_evidence_score(b, weight, corrob),
            )

    def test_monotonic_in_red_flag_weight(self):
        for _ in range(500):
            score = self.rng.uniform(0, 100)
            corrob = self.rng.randint(0, 3)
            a, b = sorted([self.rng.uniform(0, 200), self.rng.uniform(0, 200)])
            self.assertLessEqual(
                escalation_evidence_score(score, a, corrob),
                escalation_evidence_score(score, b, corrob),
            )

    def test_decision_always_resolves_no_exception_on_valid_input(self):
        # every valid random input must produce a definitive disposition --
        # this is the core architectural guarantee (no "held" state exists)
        for _ in range(2000):
            ev = EvidenceInput.create(
                max_ai_score=self.rng.uniform(0, 100),
                red_flag_weight_total=self.rng.uniform(0, 300),
                corroboration_count=self.rng.randint(0, 3),
                sanctions_match=self.rng.random() < 0.05,
            )
            decision = decide_l1_triage(ev, rng=self.rng)
            self.assertIn(decision.disposition, (Disposition.ESCALATE, Disposition.CLOSE_FALSE_POSITIVE))

    def test_qc_sample_rate_respected_within_tolerance(self):
        # over many trials, the observed QC-sample rate among closed cases
        # should be close to the configured rate (statistical, not exact)
        rng = random.Random(42)
        closed_count = 0
        sampled_count = 0
        for _ in range(20000):
            ev = EvidenceInput.create(0, 0, 0)  # guaranteed close (score 0)
            decision = decide_l1_triage(ev, qc_sample_rate=0.10, rng=rng)
            if decision.disposition == Disposition.CLOSE_FALSE_POSITIVE:
                closed_count += 1
                if decision.qc_sample:
                    sampled_count += 1
        observed_rate = sampled_count / closed_count
        self.assertAlmostEqual(observed_rate, 0.10, delta=0.02)  # generous tolerance


# ============================================================================
# STRESS TESTS
# ============================================================================
class TestStress(unittest.TestCase):
    def test_large_population_calibration_completes_quickly(self):
        rng = random.Random(7)
        population = [rng.uniform(0, 100) for _ in range(500_000)]
        start = time.perf_counter()
        result = calibrate_threshold(population, target_rate=0.02)
        elapsed = time.perf_counter() - start
        self.assertEqual(result.population_size, 500_000)
        self.assertLess(elapsed, 5.0, f"calibration took too long: {elapsed:.2f}s for 500k scores")

    def test_many_sequential_decisions_no_state_leak(self):
        # 100k sequential decisions with alternating evidence must never
        # let one call's outcome influence the next (purity check)
        rng = random.Random(99)
        seen_dispositions = set()
        for i in range(100_000):
            ev = EvidenceInput.create(
                max_ai_score=100 if i % 2 == 0 else 0,
                red_flag_weight_total=100 if i % 2 == 0 else 0,
                corroboration_count=3 if i % 2 == 0 else 0,
            )
            decision = decide_l1_triage(ev, rng=rng)
            seen_dispositions.add(decision.disposition)
        # both outcomes must appear, and every even-index call must have
        # escalated / every odd-index call must have closed, deterministically
        self.assertEqual(seen_dispositions, {Disposition.ESCALATE, Disposition.CLOSE_FALSE_POSITIVE})


if __name__ == "__main__":
    unittest.main(verbosity=2)
