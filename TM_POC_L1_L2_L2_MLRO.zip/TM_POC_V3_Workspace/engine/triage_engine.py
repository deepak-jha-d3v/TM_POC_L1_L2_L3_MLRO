"""
triage_engine.py
=================
SARA.ai L1 Auto-Triage Engine.

A pure, dependency-free scoring and decision module that answers one
question for a single AML transaction-monitoring alert: does the evidence
justify escalating this case to a human L2 investigator, or does it close
autonomously as a false positive?

Design goals (why this module exists as a standalone unit rather than
inline logic in the data-generation script):
  * Testable in isolation -- every function is pure (same input always
    produces the same output, no hidden state, no I/O).
  * Thread-safe by construction -- no module-level mutable state, so
    concurrent callers never race on anything.
  * Reusable -- the same scoring formula backs both the live decision path
    (decide_l1_triage) and the offline calibration tool
    (calibrate_threshold / scripts/calibrate_l1_triage.py), so they can
    never silently drift apart.

Not in scope for this module: sourcing the raw signals (that's the rules
engine / AI copilot's job), persistence, and anything transport-related.
This module only ever sees already-extracted numeric/boolean evidence.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Protocol, Sequence


# ============================================================================
# Constants (named, not magic numbers -- change these, not the formulas)
# ============================================================================

WEIGHT_AI_SCORE = 0.55
WEIGHT_RED_FLAG = 0.30
WEIGHT_CORROBORATION = 0.15

MAX_SCORE = 100.0
MIN_SCORE = 0.0
RED_FLAG_WEIGHT_CAP = 100.0  # red-flag weight total is clamped to this before scoring
MAX_CORROBORATION_SOURCES = 3  # PEP match, adverse media, prior AML history

DEFAULT_ESCALATION_THRESHOLD = 70.0
DEFAULT_QC_SAMPLE_RATE = 0.05

_WEIGHT_SUM = WEIGHT_AI_SCORE + WEIGHT_RED_FLAG + WEIGHT_CORROBORATION
assert math.isclose(_WEIGHT_SUM, 1.0, rel_tol=1e-9), (
    f"Scoring weights must sum to 1.0, got {_WEIGHT_SUM}"
)


class TriageError(ValueError):
    """Raised when evidence inputs are missing, malformed, or out of range.

    A compliance decision must never silently proceed on garbage input --
    fail loudly and specifically rather than let bad data produce a
    plausible-looking but meaningless score.
    """


class Disposition(str, Enum):
    ESCALATE = "escalate_to_l2"
    CLOSE_FALSE_POSITIVE = "close_false_positive"


@dataclass(frozen=True)
class EvidenceInput:
    """Validated evidence for one alert. Construct via `EvidenceInput.create`
    rather than the bare constructor so invalid data is rejected at the
    boundary, not discovered later mid-calculation."""

    max_ai_score: float
    red_flag_weight_total: float
    corroboration_count: int
    sanctions_match: bool = False

    @staticmethod
    def create(
        max_ai_score,
        red_flag_weight_total,
        corroboration_count,
        sanctions_match=False,
    ) -> "EvidenceInput":
        max_ai_score = _validate_numeric("max_ai_score", max_ai_score, MIN_SCORE, MAX_SCORE)
        red_flag_weight_total = _validate_numeric(
            "red_flag_weight_total", red_flag_weight_total, 0.0, math.inf
        )
        corroboration_count = _validate_int_range(
            "corroboration_count", corroboration_count, 0, MAX_CORROBORATION_SOURCES
        )
        if not isinstance(sanctions_match, bool):
            raise TriageError(
                f"sanctions_match must be a bool, got {type(sanctions_match).__name__}"
            )
        return EvidenceInput(max_ai_score, red_flag_weight_total, corroboration_count, sanctions_match)


@dataclass(frozen=True)
class TriageDecision:
    disposition: Disposition
    evidence_score: float | None  # None only for the mandatory-sanctions path
    threshold_used: float | None  # None only for the mandatory-sanctions path
    qc_sample: bool
    reason: str


def _validate_numeric(name: str, value, lo: float, hi: float) -> float:
    if value is None:
        raise TriageError(f"{name} is required and cannot be None")
    if isinstance(value, bool):  # bool is a subclass of int -- reject explicitly
        raise TriageError(f"{name} must be numeric, got bool")
    if not isinstance(value, (int, float)):
        raise TriageError(f"{name} must be numeric, got {type(value).__name__}")
    value = float(value)
    if math.isnan(value) or math.isinf(value):
        raise TriageError(f"{name} must be a finite number, got {value}")
    if not (lo <= value <= hi):
        raise TriageError(f"{name} must be between {lo} and {hi}, got {value}")
    return value


def _validate_int_range(name: str, value, lo: int, hi: int) -> int:
    if value is None:
        raise TriageError(f"{name} is required and cannot be None")
    if isinstance(value, bool) or not isinstance(value, int):
        raise TriageError(f"{name} must be an int, got {type(value).__name__}")
    if not (lo <= value <= hi):
        raise TriageError(f"{name} must be between {lo} and {hi}, got {value}")
    return value


def escalation_evidence_score(
    max_ai_score: float,
    red_flag_weight_total: float,
    corroboration_count: int,
) -> float:
    """Pure 0-100 composite evidence score. Requires several independent
    evidence sources to line up rather than keying off any single elevated
    number -- see module docstring for the rationale.

    Raises TriageError on invalid input. Inputs are validated here (not just
    trusted from EvidenceInput) so this function is safe to call directly
    in isolation, e.g. from the calibration tool or a test.
    """
    max_ai_score = _validate_numeric("max_ai_score", max_ai_score, MIN_SCORE, MAX_SCORE)
    red_flag_weight_total = _validate_numeric("red_flag_weight_total", red_flag_weight_total, 0.0, math.inf)
    corroboration_count = _validate_int_range(
        "corroboration_count", corroboration_count, 0, MAX_CORROBORATION_SOURCES
    )

    weight_component = min(red_flag_weight_total, RED_FLAG_WEIGHT_CAP)
    corrob_component = (corroboration_count / MAX_CORROBORATION_SOURCES) * 100.0

    score = (
        WEIGHT_AI_SCORE * max_ai_score
        + WEIGHT_RED_FLAG * weight_component
        + WEIGHT_CORROBORATION * corrob_component
    )
    # Guard against float drift pushing a couple-decimal result fractionally
    # outside [0, 100] -- the formula is a convex combination of in-range
    # components so mathematically it can't happen, but clamp defensively
    # since this score gates a compliance decision.
    return round(min(max(score, MIN_SCORE), MAX_SCORE), 1)


def decide_l1_triage(
    evidence: EvidenceInput,
    threshold: float = DEFAULT_ESCALATION_THRESHOLD,
    qc_sample_rate: float = DEFAULT_QC_SAMPLE_RATE,
    rng: "_RandomLike | None" = None,
) -> TriageDecision:
    """The full L1 auto-triage decision for one alert. Always resolves --
    there is no "held for human" outcome. `rng` is injected (not read from
    module/global state) so this function itself is pure and thread-safe;
    pass a seeded `random.Random()` instance for reproducibility, or omit it
    to disable QC sampling deterministically (defaults to "never sampled")
    rather than silently reaching for a shared global RNG.

    THREAD-SAFETY CAVEAT: this function has no shared state of its own, so
    calling it concurrently from multiple threads with independent `rng`
    instances (or none at all) is safe. If callers instead share ONE
    `random.Random()` instance across threads, that instance's internal
    state can race -- `random.Random` is not documented as thread-safe.
    Give each thread/worker its own instance (or its own seed) rather than
    sharing one.
    """
    if not isinstance(evidence, EvidenceInput):
        raise TriageError(f"evidence must be an EvidenceInput, got {type(evidence).__name__}")
    # threshold has no upper cap at MAX_SCORE: a threshold above 100 is a
    # deliberate, valid "never auto-escalate via scoring" configuration
    # (e.g. what calibrate_threshold(target_rate=0) returns), distinct from
    # a malformed negative/NaN/inf value, which IS rejected.
    threshold = _validate_numeric("threshold", threshold, 0.0, math.inf)
    if not (0.0 <= qc_sample_rate <= 1.0):
        raise TriageError(f"qc_sample_rate must be between 0 and 1, got {qc_sample_rate}")

    if evidence.sanctions_match:
        return TriageDecision(
            disposition=Disposition.ESCALATE,
            evidence_score=None,
            threshold_used=None,
            qc_sample=False,
            reason="Confirmed sanctions match -- mandatory escalation, no scoring applied.",
        )

    score = escalation_evidence_score(
        evidence.max_ai_score, evidence.red_flag_weight_total, evidence.corroboration_count
    )

    if score >= threshold:
        return TriageDecision(
            disposition=Disposition.ESCALATE,
            evidence_score=score,
            threshold_used=threshold,
            qc_sample=False,
            reason=f"Evidence score {score} >= threshold {threshold}.",
        )

    qc_sample = rng.random() < qc_sample_rate if rng is not None else False
    return TriageDecision(
        disposition=Disposition.CLOSE_FALSE_POSITIVE,
        evidence_score=score,
        threshold_used=threshold,
        qc_sample=qc_sample,
        reason=f"Evidence score {score} < threshold {threshold}.",
    )


class _RandomLike(Protocol):
    """Structural type for the `rng` parameter (duck-typed against
    random.Random, which satisfies this Protocol without any explicit
    inheritance -- e.g. `random.Random()` works directly)."""

    def random(self) -> float: ...


# ============================================================================
# Calibration: percentile-based threshold selection over a scored population
# ============================================================================

@dataclass(frozen=True)
class CalibrationResult:
    threshold: float
    population_size: int
    escalate_count: int

    @property
    def escalate_rate(self) -> float:
        if self.population_size == 0:
            return 0.0
        return self.escalate_count / self.population_size


def calibrate_threshold(
    evidence_scores: Sequence[float],
    target_rate: float = 0.10,
) -> CalibrationResult:
    """Given the evidence scores of a scored, non-sanctions population,
    recommend a threshold that escalates approximately the top
    `target_rate` fraction of that population.

    A percentile cut (not a fixed absolute score) is what lets the same
    method generalise: at small/curated demo scale it lands wherever this
    dataset's genuine standout cases are, while at real production scale --
    where the vast majority of alerts cluster at low evidence -- the same
    method naturally pushes the effective escalation rate toward whatever a
    much larger, more realistic population's own top-decile (or top-2%,
    etc.) line actually is.
    """
    if not (0.0 <= target_rate <= 1.0):
        raise TriageError(f"target_rate must be between 0 and 1, got {target_rate}")

    # Materialize FIRST: evidence_scores may be a one-shot iterable (e.g. a
    # generator). Validating it in a for-loop before this point would
    # silently exhaust it, leaving sorted()/len() below operating on an
    # empty sequence with no error raised -- a caller passing a generator
    # would get a confidently wrong "empty population" result instead of
    # their actual data being calibrated.
    scores = list(evidence_scores)
    for i, s in enumerate(scores):
        _validate_numeric(f"evidence_scores[{i}]", s, MIN_SCORE, MAX_SCORE)

    n = len(scores)
    if n == 0:
        # An empty population has no meaningful cut point. Return a
        # threshold that is genuinely unreachable (see the target_rate==0
        # branch below for why MAX_SCORE itself is not sufficient) so this
        # reads unambiguously as "escalate nothing" if used downstream.
        return CalibrationResult(threshold=MAX_SCORE + 1.0, population_size=0, escalate_count=0)

    if target_rate == 0.0:
        # Escalate literally nobody. Using the top score as the threshold
        # (the naive percentile-index approach) would still escalate an
        # entire tied group at the maximum -- not "nothing" whenever there
        # are duplicate top scores. A threshold just above MAX_SCORE is
        # mathematically unreachable by any valid (<=100) evidence score,
        # which is what "escalate nothing" actually requires.
        return CalibrationResult(threshold=MAX_SCORE + 1.0, population_size=n, escalate_count=0)

    ranked = sorted(scores, reverse=True)
    cut_index = min(max(round(n * target_rate) - 1, 0), n - 1)
    threshold = ranked[cut_index]
    escalate_count = sum(1 for s in ranked if s >= threshold)
    return CalibrationResult(threshold=threshold, population_size=n, escalate_count=escalate_count)
