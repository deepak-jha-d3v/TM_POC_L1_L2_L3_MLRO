// test_signed_in_label.js
// Verifies the sign-in label sync fix using jsdom-free minimal DOM stub,
// against setSignedInLabel() extracted VERBATIM from the shipped app.
const fs = require('fs');
const path = require('path');

const APP_PATH = path.resolve('/home/claude/tm_poc/TM_POC_V3_Workspace/output/case_review_ui.html');
const html = fs.readFileSync(APP_PATH, 'utf8');

function extractBlock(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) throw new Error('Marker not found: ' + startMarker);
  const braceStart = src.indexOf('{', start);
  let depth = 0, i = braceStart;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { i++; break; } }
  }
  return src.slice(start, i);
}

const fnSrc = extractBlock(html, 'function setSignedInLabel(text)');
if (!fnSrc.includes('userRoleLabel2')) {
  throw new Error('Extraction looks wrong -- did not find expected content');
}

// Minimal DOM stub: two elements keyed by id, both with a .textContent slot.
function makeStubDocument(ids) {
  const elements = {};
  for (const id of ids) elements[id] = { textContent: null };
  return { getElementById: (id) => elements[id] || null, __elements: elements };
}

let failures = 0;
function check(name, cond) {
  if (cond) console.log('  ok -', name);
  else { failures++; console.log('  FAIL -', name); }
}

console.log('TEST 1: setSignedInLabel updates BOTH labels in one call');
{
  const document = makeStubDocument(['userRoleLabel', 'userRoleLabel2']);
  const setSignedInLabel = new Function('document', fnSrc + '\nreturn setSignedInLabel;')(document);
  setSignedInLabel('L1 Analyst (L1)');
  check('userRoleLabel updated', document.__elements.userRoleLabel.textContent === 'L1 Analyst (L1)');
  check('userRoleLabel2 updated to the SAME value', document.__elements.userRoleLabel2.textContent === 'L1 Analyst (L1)');
}

console.log('TEST 2: regression check -- the specific "Guided Demo" bug scenario');
{
  const document = makeStubDocument(['userRoleLabel', 'userRoleLabel2']);
  const setSignedInLabel = new Function('document', fnSrc + '\nreturn setSignedInLabel;')(document);
  // Simulate a prior login leaving stale text in userRoleLabel2 (the exact
  // pre-fix failure mode), then starting the guided demo.
  document.__elements.userRoleLabel2.textContent = 'L2 Investigator (L2)'; // stale from a previous session
  setSignedInLabel('Guided Demo');
  check('userRoleLabel shows Guided Demo', document.__elements.userRoleLabel.textContent === 'Guided Demo');
  check('userRoleLabel2 ALSO shows Guided Demo (no longer stale)', document.__elements.userRoleLabel2.textContent === 'Guided Demo');
}

console.log('TEST 3: does not throw if one element is missing from the DOM (defensive guard)');
{
  const document = makeStubDocument(['userRoleLabel']); // userRoleLabel2 missing entirely
  const setSignedInLabel = new Function('document', fnSrc + '\nreturn setSignedInLabel;')(document);
  let threw = false;
  try { setSignedInLabel('MLRO / Compliance (MLRO)'); } catch (e) { threw = true; console.log('    exception:', e.message); }
  check('does not throw when userRoleLabel2 is missing', !threw);
  check('still updates the element that DOES exist', document.__elements.userRoleLabel.textContent === 'MLRO / Compliance (MLRO)');
}

console.log('TEST 4: verify all three real call sites in the shipped app route through setSignedInLabel (no direct textContent assignment left)');
{
  const scriptMatch = [...html.matchAll(/<script(?:(?! src)[^>])*>([\s\S]*?)<\/script>/g)]
    .sort((a, b) => b[1].length - a[1].length)[0][1];
  const directAssignsOutsideHelper = (() => {
    // Remove the helper's own body first, then check the REST of the script
    // for any remaining direct assignment to these two ids.
    const rest = scriptMatch.replace(fnSrc, '');
    return [...rest.matchAll(/getElementById\('userRoleLabel2?'\)\.textContent\s*=/g)].length;
  })();
  check('zero direct textContent assignments to userRoleLabel/2 outside the helper', directAssignsOutsideHelper === 0);
  const callCount = [...scriptMatch.matchAll(/setSignedInLabel\(/g)].length - 1; // -1 for the function declaration itself
  check('setSignedInLabel is actually called at least 3 times (doLogin, startGuidedDemo, demoOpenFullCase)', callCount >= 3);
}

console.log('\n' + (failures === 0 ? 'ALL TESTS PASSED' : `${failures} TEST(S) FAILED`));
process.exit(failures === 0 ? 0 : 1);
