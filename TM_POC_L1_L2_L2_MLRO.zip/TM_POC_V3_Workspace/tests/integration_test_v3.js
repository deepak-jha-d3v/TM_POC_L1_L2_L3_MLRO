const { chromium } = require('playwright');
const path = require('path');

const FILE = 'file://' + path.resolve('/home/claude/tm_poc/TM_POC_V3_Workspace/output/case_review_ui.html');
let failures = 0;
function check(name, cond) {
  if (cond) console.log('  ok -', name);
  else { failures++; console.log('  FAIL -', name); }
}

async function loginAs(page, role) {
  await page.goto(FILE);
  await page.fill('#loginUser', role);
  await page.fill('#loginPass', role);
  await page.evaluate(() => doLogin());
  await page.waitForTimeout(300);
}

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  let pageErrors = 0;
  page.on('pageerror', err => { pageErrors++; console.log('  PAGE EXCEPTION:', err.message); });
  page.on('console', msg => { if (msg.type() === 'error' && !msg.text().includes('403')) { pageErrors++; console.log('  CONSOLE ERROR:', msg.text()); } });

  console.log('TEST 1: notification bell is gone from both headers');
  await loginAs(page, 'L1');
  let bellCount = await page.locator('button[title="Notifications"]').count();
  check('bell not present on dashboard header', bellCount === 0);
  // open a case to reveal the investigation header
  const firstAlertId = await page.evaluate(() => ALERTS[0].alert_id);
  await page.evaluate((id) => openInvestigation(id), firstAlertId);
  await page.waitForTimeout(300);
  bellCount = await page.locator('button[title="Notifications"]').count();
  check('bell not present on investigation header', bellCount === 0);
  const profileBtnCount = await page.locator('button[title="Profile"]').count();
  check('dead profile icon-button also removed', profileBtnCount === 0);

  console.log('TEST 2: no lingering QC nav tab or view');
  await loginAs(page, 'L3');
  const qcTabCount = await page.locator('button.tab-btn:has-text("QC History")').count();
  check('QC History tab no longer exists', qcTabCount === 0);
  const qcViewExists = await page.evaluate(() => !!document.getElementById('qcHistoryView'));
  check('qcHistoryView element no longer exists in DOM', !qcViewExists);

  console.log('TEST 3: role queues reflect the simplified 4-stage lifecycle');
  for (const role of ['L1', 'L2', 'L3', 'MLRO']) {
    await loginAs(page, role);
    const kpis = await page.evaluate(() => Array.from(document.querySelectorAll('.kpi .kpi-val')).map(e => e.textContent.trim()));
    console.log(`  [${role}] KPIs:`, kpis);
  }

  console.log('TEST 4: no alert anywhere is ever at an L1_QC/L2_QC stage');
  const stageCheck = await page.evaluate(() => {
    const custIds = new Set(ALERTS.map(a => a.customer_id));
    const badStages = [];
    for (const cid of custIds) {
      const inv = INV_DATA[cid];
      if (!inv || !inv.case_workflow) continue;
      if (['L1_QC', 'L2_QC'].includes(inv.case_workflow.current_stage)) badStages.push(cid);
      for (const s of inv.case_workflow.stages) {
        if (['L1_QC', 'L2_QC'].includes(s.stage)) badStages.push(cid + ':' + s.stage);
      }
    }
    return badStages;
  });
  check('zero customers with an L1_QC/L2_QC stage anywhere', stageCheck.length === 0);

  console.log('TEST 5: Case Lifecycle view renders the new 4-stage rail correctly for an escalated case');
  await loginAs(page, 'MLRO');
  const escalatedId = await page.evaluate(() => {
    const custIds = Object.keys(INV_DATA);
    for (const cid of custIds) {
      const d = INV_DATA[cid].ai_l1_decision;
      if (d.final_action === 'escalate_to_l2') {
        const a = ALERTS.find(x => x.customer_id === cid);
        if (a) return a.alert_id;
      }
    }
    return null;
  });
  check('found an escalated case to test with', !!escalatedId);
  await page.evaluate((id) => openInvestigation(id), escalatedId);
  await page.waitForTimeout(200);
  await page.evaluate(() => showSection('lifecycle'));
  await page.waitForTimeout(300);
  const railText = await page.locator('body').innerText();
  check('rail shows L1', railText.includes('L1 Analyst Review'));
  check('rail shows L2', railText.includes('L2 Investigation'));
  check('rail shows L3 Review (renamed from L3 Deep Investigation)', railText.includes('L3 Review'));
  check('rail shows MLRO', railText.includes('Compliance / MLRO'));
  check('no QC stage label anywhere in the lifecycle view', !railText.includes('QC (of L1)') && !railText.includes('QC (of L2)') && !railText.includes('Quality Control'));

  console.log('TEST 6: signed-in label sync -- dashboard and investigation headers always match');
  await loginAs(page, 'L2');
  const dashLabel = await page.locator('#userRoleLabel').innerText();
  await page.evaluate((id) => openInvestigation(id), firstAlertId);
  await page.waitForTimeout(200);
  const invLabel = await page.locator('#userRoleLabel2').innerText();
  check('dashboard label and investigation label match after normal login', dashLabel === invLabel && dashLabel.length > 0);

  console.log('TEST 7: signed-in label sync -- guided demo path (the actual regression scenario)');
  await page.goto(FILE);
  // Log in first (to populate userRoleLabel2 with something), then log out,
  // then start the guided demo -- this recreates the exact stale-data
  // scenario the original bug needed to manifest.
  await page.fill('#loginUser', 'L2');
  await page.fill('#loginPass', 'L2');
  await page.evaluate(() => doLogin());
  await page.waitForTimeout(200);
  const firstId = await page.evaluate(() => ALERTS[0].alert_id);
  await page.evaluate((id) => openInvestigation(id), firstId); // populates userRoleLabel2
  await page.waitForTimeout(200);
  await page.evaluate(() => doLogout());
  await page.waitForTimeout(200);
  await page.evaluate(() => startGuidedDemo());
  await page.waitForTimeout(300);
  const demoLabelDash = await page.locator('#userRoleLabel').innerText();
  check('dashboard header shows "Guided Demo"', demoLabelDash === 'Guided Demo');
  // Now enter the full case file from within the demo -- this is where the
  // investigation header (userRoleLabel2) becomes visible.
  await page.evaluate(() => demoOpenFullCase());
  await page.waitForTimeout(300);
  const roleAfterDemoOpen = await page.evaluate(() => CURRENT_ROLE);
  const invLabelAfterDemo = await page.locator('#userRoleLabel2').innerText();
  check('investigation header role label is populated (not blank/stale)', invLabelAfterDemo.length > 0);
  check('investigation header label matches the role the demo actually signed in as', invLabelAfterDemo.includes(roleAfterDemoOpen));

  console.log('\nTotal unexpected page/console errors:', pageErrors);
  await browser.close();

  console.log('\n' + (failures === 0 && pageErrors === 0 ? 'ALL INTEGRATION TESTS PASSED' : `${failures} FAILURE(S), ${pageErrors} PAGE ERROR(S)`));
  process.exit(failures === 0 && pageErrors === 0 ? 0 : 1);
})().catch(e => { console.error('SCRIPT FAILED:', e); process.exit(1); });
