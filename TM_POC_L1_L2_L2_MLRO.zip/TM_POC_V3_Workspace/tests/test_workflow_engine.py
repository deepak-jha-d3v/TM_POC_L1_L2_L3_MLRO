"""
test_workflow_engine.py
========================
Unit tests for the simplified 4-stage case lifecycle in workflow_engine.py
(L1_QC / L2_QC removed). Stdlib-only (unittest).

Run: python3 -m unittest test_workflow_engine.py -v
"""

import unittest

import workflow_engine as wf


def make_minimal_inv(customer_id, final_action, requires_human_review=False,
                      score=60, red_flags=None):
    """Builds the minimal investigation record shape build_case_workflow()
    needs, without going through the full data-generation pipeline."""
    return {
        "customer_id": customer_id,
        "alert_date": "2026-01-01 10:00",
        "ai_l1_decision": {
            "final_action": final_action,
            "requires_human_review": requires_human_review,
            "max_ai_confidence_score": score,
            "decision_summary": "test",
            "review_reasons": [],
        },
        "risk_snapshot": {"overall_risk_score": score},
        "red_flags": red_flags or [{"flag": "Test Flag", "triggered": "Y", "weight": 10}],
    }


class TestStageConfigConsistency(unittest.TestCase):
    """Every stage-keyed dict must have exactly the same key set as STAGES --
    a mismatch here would KeyError deep inside build_case_workflow()."""

    def test_stages_has_no_qc_entries(self):
        self.assertNotIn("L1_QC", wf.STAGES)
        self.assertNotIn("L2_QC", wf.STAGES)

    def test_stages_is_exactly_the_four_expected_stages_in_order(self):
        self.assertEqual(wf.STAGES, ["L1_REVIEW", "L2_REVIEW", "MLRO_L3", "MLRO_DECISION"])

    def test_stage_labels_keys_match_stages(self):
        self.assertEqual(set(wf.STAGE_LABELS.keys()), set(wf.STAGES))

    def test_stage_role_keys_match_stages(self):
        self.assertEqual(set(wf.STAGE_ROLE.keys()), set(wf.STAGES))

    def test_stage_checklists_keys_match_stages(self):
        self.assertEqual(set(wf.STAGE_CHECKLISTS.keys()), set(wf.STAGES))

    def test_stage_actions_keys_match_stages(self):
        self.assertEqual(set(wf.STAGE_ACTIONS.keys()), set(wf.STAGES))

    def test_advancing_action_keys_match_stages(self):
        self.assertEqual(set(wf.ADVANCING_ACTION.keys()), set(wf.STAGES))

    def test_every_advancing_action_is_a_valid_action_for_its_stage(self):
        for stage, action in wf.ADVANCING_ACTION.items():
            self.assertIn(action, wf.STAGE_ACTIONS[stage],
                           f"{action} not in STAGE_ACTIONS[{stage}]")

    def test_every_action_referenced_by_stage_actions_has_a_label(self):
        for stage, actions in wf.STAGE_ACTIONS.items():
            for action in actions:
                self.assertIn(action, wf.ACTION_LABELS, f"{action} (stage {stage}) has no label")

    def test_no_qc_actions_remain_in_action_labels(self):
        for dead_action in ("pass_l1", "return_to_l1", "pass_l2", "return_to_l2"):
            self.assertNotIn(dead_action, wf.ACTION_LABELS)

    def test_every_stage_role_has_an_analyst_pool(self):
        # _hitl() does r.choice(ANALYSTS[role]) -- a missing pool is a KeyError at runtime.
        for stage, role in wf.STAGE_ROLE.items():
            self.assertIn(role, wf.ANALYSTS, f"No analyst pool for role '{role}' (stage {stage})")

    def test_l3_qc_reviewer_pool_removed(self):
        self.assertNotIn("L3 QC Reviewer", wf.ANALYSTS)


class TestContradictorySignature(unittest.TestCase):
    def test_takes_two_args_not_three(self):
        import inspect
        sig = inspect.signature(wf._contradictory)
        self.assertEqual(list(sig.parameters.keys()), ["conf", "r"])

    def test_borderline_band_always_contradictory(self):
        import random
        r = random.Random(1)
        for conf in range(48, 59):
            self.assertTrue(wf._contradictory(conf, r), f"conf={conf} should be contradictory")

    def test_outside_band_is_probabilistic_not_always_true(self):
        import random
        r = random.Random(2)
        results = [wf._contradictory(90, r) for _ in range(200)]
        # not literally 0.12 exactly, but should be well under "always true"
        self.assertLess(sum(results), 200, "expected some non-contradictory outcomes at conf=90")
        self.assertGreater(sum(results), 0, "expected at least some contradictory draws over 200 trials")


class TestBuildCaseWorkflow(unittest.TestCase):
    def test_closed_false_positive_never_advances_past_l1(self):
        inv = make_minimal_inv("CUST_TEST_01", "close_false_positive", score=20)
        result = wf.build_case_workflow(inv)
        self.assertEqual(result["stages_completed"], ["L1_REVIEW"])
        self.assertEqual(result["current_stage"], "L1_REVIEW")
        self.assertNotIn("L1_QC", result["stages_completed"])

    def test_escalated_case_never_produces_qc_stage_names(self):
        # run several seeds; escalated cases stochastically advance different
        # distances, but should NEVER contain L1_QC/L2_QC regardless of RNG path.
        for i in range(30):
            inv = make_minimal_inv(f"CUST_TEST_ESC_{i}", "escalate_to_l2", score=80)
            result = wf.build_case_workflow(inv)
            for stage_name in result["stages_completed"]:
                self.assertNotIn(stage_name, ("L1_QC", "L2_QC"),
                                  f"seed {i}: found removed QC stage in stages_completed")
            for stage_block in result["stages"]:
                self.assertNotIn(stage_block["stage"], ("L1_QC", "L2_QC"))

    def test_escalated_case_goes_straight_from_l1_to_l2(self):
        inv = make_minimal_inv("CUST_TEST_02", "escalate_to_l2", score=80)
        result = wf.build_case_workflow(inv)
        self.assertGreaterEqual(len(result["stages_completed"]), 2)
        self.assertEqual(result["stages_completed"][0], "L1_REVIEW")
        self.assertEqual(result["stages_completed"][1], "L2_REVIEW")

    def test_outcome_string_never_mentions_qc(self):
        for i in range(30):
            inv = make_minimal_inv(f"CUST_TEST_QC_{i}", "escalate_to_l2", score=80)
            result = wf.build_case_workflow(inv)
            self.assertNotIn("QC", result["outcome"], f"seed {i}: outcome mentions QC: {result['outcome']}")

    def test_result_shape_has_required_top_level_keys(self):
        inv = make_minimal_inv("CUST_TEST_03", "close_false_positive", score=10)
        result = wf.build_case_workflow(inv)
        for key in ("risk_category", "stages_completed", "current_stage",
                    "current_stage_label", "outcome", "sar_filed", "stages"):
            self.assertIn(key, result)

    def test_deterministic_same_customer_id_same_result(self):
        inv1 = make_minimal_inv("CUST_DETERMINISTIC", "escalate_to_l2", score=75)
        inv2 = make_minimal_inv("CUST_DETERMINISTIC", "escalate_to_l2", score=75)
        r1 = wf.build_case_workflow(inv1)
        r2 = wf.build_case_workflow(inv2)
        self.assertEqual(r1["stages_completed"], r2["stages_completed"])
        self.assertEqual(r1["outcome"], r2["outcome"])


class TestLifecycleOutcomeStrings(unittest.TestCase):
    def _stage(self, stage, action):
        return {"stage": stage, "effective_action": action, "ai_action": action}

    def test_closed_at_l1(self):
        stages = [self._stage("L1_REVIEW", "close_l1")]
        self.assertEqual(wf._lifecycle_outcome(stages), "Closed at L1")

    def test_sar_filed(self):
        stages = [self._stage("MLRO_DECISION", "file_sar_str")]
        self.assertEqual(wf._lifecycle_outcome(stages), "SAR/STR Filed")

    def test_closed_no_sar(self):
        stages = [self._stage("MLRO_DECISION", "close_no_sar")]
        self.assertEqual(wf._lifecycle_outcome(stages), "Closed - No SAR (MLRO)")

    def test_in_progress_l2(self):
        stages = [self._stage("L2_REVIEW", "request_info")]
        self.assertEqual(wf._lifecycle_outcome(stages), "Awaiting Requested Information (L2)")

    def test_no_qc_branch_reachable(self):
        # Even if a bogus "QC"-like stage/action snuck in, confirm the old
        # QC-specific branch text can never be produced by any real path.
        for stage in wf.STAGES:
            for action in wf.STAGE_ACTIONS[stage]:
                outcome = wf._lifecycle_outcome([self._stage(stage, action)])
                self.assertNotIn("Returned by QC", outcome)


if __name__ == "__main__":
    unittest.main(verbosity=2)
